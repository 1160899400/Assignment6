package gui;

import information.user.ModifyInfo;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class DiaGui {
	private JButton agree;
	private JFrame DiaFr;
	private String Acc;
	public DiaGui(String acc){
		Acc = acc;
		setFr();
		addLabel();
		addAgree();
	}
	private void setFr(){
		DiaFr = new JFrame("ȷ��֧��������");
		DiaFr.setLayout(null);
		DiaFr.setVisible(true);
		DiaFr.setResizable(false);
		DiaFr.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		DiaFr.setBounds(470,220, 430, 300);
		ImageIcon LoginIcon = new ImageIcon("1.jpg");
		DiaFr.setIconImage(LoginIcon.getImage());
		Color c = new Color(255,248,220);
		DiaFr.getContentPane().setBackground(c);
	}
	private void addLabel(){
		Font f = new Font("����",Font.PLAIN,15);
		JLabel Lab = new JLabel("�����Ҫ����˳������⽫�ķ���1Ԫ");
		Lab.setFont(f);
		Lab.setBounds(30, 50, 400, 30);
		DiaFr.add(Lab);
	}
	private void addAgree(){
		Color c = new Color(100,149,237);
		Font font = new Font("����",Font.BOLD,18);
		agree = new JButton("ȷ ��");
		agree.setBounds(170, 180, 90, 40);
		agree.setBorderPainted(false);
		agree.setBackground(c);
		agree.setFont(font);
		agree.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				ModifyInfo mod = new ModifyInfo(Acc);
				DiaFr.dispose();
			}
		});
		DiaFr.add(agree);
	}
}
