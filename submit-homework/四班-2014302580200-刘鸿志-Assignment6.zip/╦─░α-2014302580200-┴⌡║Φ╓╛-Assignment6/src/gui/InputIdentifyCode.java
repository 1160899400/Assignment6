package gui;

import register.*;
import information.user.*;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class InputIdentifyCode {
	private JFrame InIdCo;
	private JTextField code;
	private JButton Send;
	private JButton Agree;
	private JButton Cancel;
	private String Account;
	private String Password;
	private String Mail;
	
	public InputIdentifyCode(String acc,String pas,String ma){
		Account = acc;
		Password = pas;
		Mail = ma;
		setInputFr();
		addLabels();
		addSend();
		addAgree();
		addCancel();
		addTextField();
		InIdCo.repaint();
		}
	
	public void setInputFr(){
		InIdCo = new JFrame("������֤��");
		InIdCo.setLayout(null);
		InIdCo.setBounds(400, 180, 400, 300);
		InIdCo.setVisible(true);
		InIdCo.setResizable(false);
		InIdCo.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		ImageIcon LoginIcon = new ImageIcon("1.jpg");
		InIdCo.setIconImage(LoginIcon.getImage());
		Color c = new Color(255,248,220);
		InIdCo.getContentPane().setBackground(c);
	}
	public void addLabels(){
		Font f = new Font("����",Font.PLAIN,10);
		JLabel Lab1 = new JLabel("���������֤�������䣺");
		Lab1.setFont(f);
		Lab1.setBounds(50, 40, 200, 60);
		InIdCo.add(Lab1);
		
		JLabel Lab2 = new JLabel("��������֤�룺");
		Lab2.setFont(f);
		Lab2.setBounds(50, 100, 200, 60);
		InIdCo.add(Lab2);	
	}
	//���ӷ��Ͱ�ť
	public void addSend(){
		Color c = new Color(100,149,237);
		Font font = new Font("����",Font.BOLD,18);
		Send = new JButton("����");
		Send.setBounds(250, 60, 100, 30);
		Send.setBorderPainted(false);
		Send.setBackground(c);
		Send.setFont(font);
		Send.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				SendMail send = new SendMail(Mail);
			}
		});
		Send.setVisible(true);
		InIdCo.add(Send);
	}
	
	public void addAgree(){
		Color c = new Color(100,149,237);
		Font font = new Font("����",Font.BOLD,18);
		Agree = new JButton("ȷ��");
		Agree.setBounds(70, 200, 100, 30);
		Agree.setBorderPainted(false);
		Agree.setBackground(c);
		Agree.setFont(font);
		Agree.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				if(code.getText().equals("123456"))
				{
					AddInfo add = new AddInfo(Account,Password,Mail);
				}
				
				InIdCo.dispose();
			}
		});
		Agree.setVisible(true);
		InIdCo.add(Agree);
	}
	public void addCancel(){
		Color c = new Color(100,149,237);
		Font font = new Font("����",Font.BOLD,18);
		Cancel = new JButton("ȡ��");
		Cancel.setBounds(200, 200, 100, 30);
		Cancel.setBorderPainted(false);
		Cancel.setBackground(c);
		Cancel.setFont(font);
		Cancel.setVisible(true);
		Cancel.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				InIdCo.dispose();
			}
		});
		InIdCo.add(Cancel);
	}
	public void addTextField(){
		code = new JTextField();
		code.setBounds(250, 110, 100, 30);
		InIdCo.add(code);
	}
}
