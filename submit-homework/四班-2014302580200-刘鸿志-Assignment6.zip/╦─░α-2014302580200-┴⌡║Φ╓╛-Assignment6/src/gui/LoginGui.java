package gui;
import login.*;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;
public class LoginGui {
	private JFrame LoginFr;
	private JButton Enter;
	private JButton Register;
	private JTextField Account;
	private JPasswordField Password;
	private JLabel Notice;
	private String Acc;
	private String Pas;
	
	//������½�����gui
	public LoginGui(){
		this.setLoginFr();
		this.addButtonEnter();
		this.addButtonRegister();
		this.setTextFie();	
		LoginFr.repaint();
	}
	
	//���õ�½����JFrame�Ĳ���
	private void setLoginFr(){
		LoginFr = new JFrame("   ��  ��  ��  ��  ��  ��  ��   ��  ½  ��  ��");
		LoginFr.setLayout(null);
		LoginFr.setVisible(true);
		LoginFr.setResizable(false);
		LoginFr.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		LoginFr.setBounds(470,220, 430, 300);
		ImageIcon LoginIcon = new ImageIcon("1.jpg");
		LoginFr.setIconImage(LoginIcon.getImage());
		Color c = new Color(255,248,220);
		LoginFr.getContentPane().setBackground(c);
		
	}
	
	//���Ӱ�ť�Լ��밴ť��Ӧ�ļ����¼�����¼��ť��
	private void addButtonEnter(){
		Color c = new Color(100,149,237);
		Font font = new Font("����",Font.BOLD,18);
		Enter = new JButton("��  ¼");
		Enter.setBounds(70, 200, 110, 30);
		Enter.setBorderPainted(false);
		Enter.setBackground(c);
		Enter.setFont(font);
		Enter.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				setAcc(Account.getText());
				setPas(Password.getPassword().toString());
				LoginAuth Authenticator = new LoginAuth();
				if(Authenticator.Auth(Acc, Pas)){
					LoginFr.dispose();
					PlatformGui p = new PlatformGui(Account.getText());
					//�ɹ���½
				}
				else{
					Notice.setText("��������������򲻴��ڸ��ʺţ�����������");
				}
			}
		});
		Enter.setVisible(true);
		LoginFr.add(Enter);
	    }
	
	private void addButtonRegister(){
		Color c = new Color(100,149,237);
		Font font = new Font("����",Font.BOLD,18);
		Register = new JButton("ע  ��");
		Register.setBounds(230, 200, 110, 30);
		Register.setBorderPainted(false);
		Register.setBackground(c);
		Register.setFont(font);
		Register.setVisible(true);
		Register.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				RegisterGui b = new RegisterGui();
			}
		});
		LoginFr.add(Register);
		}
	
	//����textfield��Label
	private void setTextFie(){
		Font font = new Font("����",Font.BOLD,18);
		
		JLabel Lab1 = new JLabel("�� ��:");
		Lab1.setFont(font);
		Lab1.setBounds(70, 50, 60, 30);
		LoginFr.add(Lab1);
		
		JLabel Lab2= new JLabel("�� ��:");
		Lab2.setFont(font);
		Lab2.setBounds(70, 100, 60, 30);
		LoginFr.add(Lab2);
		
		Notice = new JLabel("                         �����ʺţ�����ע��");
		Notice.setBounds(70, 150, 200, 20);
		LoginFr.add(Notice);
		
		Account = new JTextField();
		Account.setBounds(140, 50, 200, 30);
		LoginFr.add(Account);
		
		Password = new JPasswordField();
		Password.setBounds(140, 100, 200, 30);
		LoginFr.add(Password);
	}
	
	//���úͻ�ȡ�ʺ�����
	private void setAcc(String s){
		Acc = s;
	}
	public String getAcc(){
		return Acc;
	}
	private void setPas(String s){
		Pas = s;
	}
	public String getPas(){
		return Pas;
	}	
}
