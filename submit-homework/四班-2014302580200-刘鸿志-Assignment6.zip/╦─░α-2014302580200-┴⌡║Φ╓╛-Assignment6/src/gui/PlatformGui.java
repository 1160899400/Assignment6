package gui;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;
import javax.swing.border.Border;

public class PlatformGui {
	private String ACC;
	private JFrame PlFr;
	private JButton butt1,butt2,butt3,butt4,butt5,butt6;
	
	public PlatformGui(String acc){
		ACC = acc;
		setFr();
		setLabel();
		addButton();
		PlFr.repaint();
	}
	private void setFr(){
		PlFr = new JFrame("   ��  ��  ��  ��  ��  ��  ��   ");
		PlFr.setLayout(null);
		PlFr.setVisible(true);
		PlFr.setResizable(false);
		PlFr.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		PlFr.setBounds(250, 30, 750, 600);
		ImageIcon LoginIcon = new ImageIcon("1.jpg");
		PlFr.setIconImage(LoginIcon.getImage());
		Color c = new Color(255,248,220);
		PlFr.getContentPane().setBackground(c);
	} 
	
	private void setLabel(){
		Font f = new Font("����",Font.PLAIN,15);
		
		JLabel Lab1 = new JLabel("<html>"+"<center>"+"��"+"</center>"+"<br>"+"<center>"+"�����ܣ���ʳ"+"</center>"+"<br>"+"��1.00"+"</html>");
		Lab1.setFont(f);
		Lab1.setBounds(150, 40, 100, 100);
		Lab1.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		PlFr.add(Lab1);
		
		JLabel Lab2 = new JLabel("<html>"+"<center>"+"��"+"</center>"+"<br>"+"<center>"+"�����ܣ���ʳ"+"</center>"+"<br>"+"��1.00"+"</html>");
		Lab2.setFont(f);
		Lab2.setBounds(300, 40, 100, 100);
		Lab2.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		PlFr.add(Lab2);
		
		JLabel Lab3 = new JLabel("<html>"+"<center>"+"è"+"</center>"+"<br>"+"<center>"+"�����ܣ���ʳ"+"</center>"+"<br>"+"��1.00"+"</html>");
		Lab3.setFont(f);
		Lab3.setBounds(450, 40, 100, 100);
		Lab3.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		PlFr.add(Lab3);
		
		JLabel Lab4 = new JLabel("<html>"+"<center>"+"�ڹ�"+"</center>"+"<br>"+"<center>"+"���У���ʳ"+"</center>"+"<br>"+"��1.00"+"</html>");
		Lab4.setFont(f);
		Lab4.setBounds(150, 250, 100, 100);
		Lab4.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		PlFr.add(Lab4);
		
		JLabel Lab5 = new JLabel("<html>"+"<center>"+"����"+"</center>"+"<br>"+"<center>"+"���裬˵�˻�"+"</center>"+"<br>"+"��1.00"+"</html>");
		Lab5.setFont(f);
		Lab5.setBounds(300, 250, 100, 100);
		Lab5.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		PlFr.add(Lab5);
		
		JLabel Lab6 = new JLabel("<html>"+"<center>"+"����"+"</center>"+"<br>"+"<center>"+"���ã�ʳ����"+"</center>"+"<br>"+"��1.00"+"</html>");
		Lab6.setFont(f);
		Lab6.setBounds(450, 250, 100, 100);
		Lab6.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		PlFr.add(Lab6);
	}
	
	private void addButton(){
		Color c = new Color(100,149,237);
		Font font = new Font("����",Font.BOLD,18);
		butt1 = new JButton("����");
		butt1.setBounds(150, 170, 100, 30);
		butt1.setBorderPainted(false);
		butt1.setBackground(c);
		butt1.setFont(font);
		butt1.setVisible(true);
		butt1.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				DiaGui b = new DiaGui(ACC);
			}
		});
		PlFr.add(butt1);
		
		butt2 = new JButton("����");
		butt2.setBounds(300, 170, 100, 30);
		butt2.setBorderPainted(false);
		butt2.setBackground(c);
		butt2.setFont(font);
		butt2.setVisible(true);
		butt2.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				DiaGui b = new DiaGui(ACC);
			}
		});
		PlFr.add(butt2);
		
		butt3 = new JButton("����");
		butt3.setBounds(450, 170, 100, 30);
		butt3.setBorderPainted(false);
		butt3.setBackground(c);
		butt3.setFont(font);
		butt3.setVisible(true);
		butt3.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				DiaGui b = new DiaGui(ACC);
			}
		});
		PlFr.add(butt3);
		
		butt4 = new JButton("����");
		butt4.setBounds(150, 380, 100, 30);
		butt4.setBorderPainted(false);
		butt4.setBackground(c);
		butt4.setFont(font);
		butt4.setVisible(true);
		butt4.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				DiaGui b = new DiaGui(ACC);
			}
		});
		PlFr.add(butt4);
		
		butt5 = new JButton("����");
		butt5.setBounds(300, 380, 100, 30);
		butt5.setBorderPainted(false);
		butt5.setBackground(c);
		butt5.setFont(font);
		butt5.setVisible(true);
		butt5.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				DiaGui b = new DiaGui(ACC);
			}
		});
		PlFr.add(butt5);
		
		butt6 = new JButton("����");
		butt6.setBounds(450, 380, 100, 30);
		butt6.setBorderPainted(false);
		butt6.setBackground(c);
		butt6.setFont(font);
		butt6.setVisible(true);
		butt6.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				DiaGui b = new DiaGui(ACC);
			}
		});
		PlFr.add(butt6);
		

		
		
	}
	
}
