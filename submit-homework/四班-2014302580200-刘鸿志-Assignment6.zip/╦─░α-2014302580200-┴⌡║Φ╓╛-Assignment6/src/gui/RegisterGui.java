package gui;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class RegisterGui {
	private String RegAcc,RegPas,RegMail;
	private JTextField Reg1,Reg2,Reg3; 
	private JFrame RegFr;
	private JButton Agree,Cancel;
	
	public RegisterGui(){
		this.setRegFr();
		this.addScr();
		this.addButtAgree();
		this.addButtCancel();
		RegFr.repaint();		
	}
	
	//ע���ʺŽ���
	public void setRegFr(){
		RegFr = new JFrame("ע���ʺ�");
		RegFr.setLayout(null);
		RegFr.setVisible(true);
		RegFr.setResizable(false);
		RegFr.setBounds(400, 180, 440, 300);
		RegFr.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		ImageIcon LoginIcon = new ImageIcon("1.jpg");
		RegFr.setIconImage(LoginIcon.getImage());
		Color c = new Color(255,248,220);
		RegFr.getContentPane().setBackground(c);
	}
	
	private void addScr(){
		Font f = new Font("����",Font.PLAIN,20);
		JLabel Lab1 = new JLabel("�ʺţ�");
		Lab1.setFont(f);
		Lab1.setBounds(50, 40, 60, 30);
		RegFr.add(Lab1);
		
		JLabel Lab2 = new JLabel("���룺");
		Lab2.setFont(f);
		Lab2.setBounds(50, 90, 60, 30);
		RegFr.add(Lab2);
		
		JLabel Lab3 = new JLabel("���䣺");
		Lab3.setFont(f);
		Lab3.setBounds(50, 140, 60, 30);
		RegFr.add(Lab3);
		
		Reg1 = new JTextField();
		Reg1.setBounds(120, 40, 250, 30);
		RegFr.add(Reg1);
		
		Reg2 = new JTextField();
		Reg2.setBounds(120, 90, 250, 30);
		RegFr.add(Reg2);
		
		Reg3 = new JTextField();
		Reg3.setBounds(120, 140, 250, 30);
		RegFr.add(Reg3);	
	}
	
	private void addButtAgree(){
		Color c = new Color(100,149,237);
		Font font = new Font("����",Font.BOLD,18);
		Agree = new JButton("ȷ ��");
		Agree.setBounds(90, 210, 90, 40);
		Agree.setBorderPainted(false);
		Agree.setBackground(c);
		Agree.setFont(font);
		Agree.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				setRegInfo(Reg1.getText(),Reg2.getText(),Reg3.getText());
				InputIdentifyCode d = new InputIdentifyCode(RegAcc,RegPas,RegMail);
			}
		});
		RegFr.add(Agree);
	}
	private void addButtCancel(){
		Color c = new Color(100,149,237);
		Font font = new Font("����",Font.BOLD,18);
		Cancel = new JButton("ȡ ��");
		Cancel.setBounds(230, 210, 90, 40);
		Cancel.setBorderPainted(false);
		Cancel.setBackground(c);
		Cancel.setFont(font);
		Cancel.setVisible(true);
		Cancel.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				RegFr.dispose();
			}
		});
		RegFr.add(Cancel);
		
		
	}
	
	private void setRegInfo(String AccInfo,String PasInfo,String MailInfo){
		RegAcc = AccInfo;
		RegPas = PasInfo;
		RegMail = MailInfo;
	}
	public String getRegAcc(){
		return RegAcc;
	}
	public String getRegPas(){
		return RegPas;
	}
	public String getRegMail(){
		return RegMail;
	}
}
