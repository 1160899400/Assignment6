package information.user;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class AddInfo {
	public AddInfo(String user,String password,String mail){
		insertInfo( user, password, mail);
	}
	public boolean insertInfo(String user,String password,String mail){
		ArrayList<String>account = new ArrayList<String>();
		
		final String URL = "jdbc:mysql://localhost:3306/my_schema?user=root&password=liu19960623&useUnicode=true&characterEncoding=UTF8";
		//final String URL = "jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456";
		final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
		Connection conn = null;
		Statement stmt = null;
		try {
			Class.forName(JDBC_DRIVER);
			conn = DriverManager.getConnection(URL);
			stmt = conn.createStatement();
			String sql = "SELECT account, password, mail, money FROM 2014302580200_user";
			ResultSet rs = stmt.executeQuery(sql);
			while(rs.next()){
				account.add(rs.getString("account"));
				}
			if(!account.contains(user)){
			sql = "INSERT INTO 2014302580200_user(account,password,mail,money)"+"VALUES('"+user+"','"+password+"','"+mail+"',20.00)";
			stmt.executeUpdate(sql);
			}
			else{
				return false;
			}
			} catch (ClassNotFoundException | SQLException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
		return true;
	}
	

}
