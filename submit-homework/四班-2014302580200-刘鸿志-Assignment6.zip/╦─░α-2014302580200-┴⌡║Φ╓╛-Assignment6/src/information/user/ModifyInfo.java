package information.user;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class ModifyInfo {
	private String ACC;
	public ModifyInfo(String acc){
		ACC = acc;
		final String URL = "jdbc:mysql://localhost:3306/my_schema?user=root&password=liu19960623&useUnicode=true&characterEncoding=UTF8";
		//final String URL = "jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456";
		final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
		Connection conn = null;
		Statement stmt = null;
		try {
			ArrayList<String>account =new ArrayList<String>();
			ArrayList<Double>money = new ArrayList<Double>();
			Class.forName(JDBC_DRIVER);
			conn = DriverManager.getConnection(URL);
			stmt = conn.createStatement();
			String sql = "SELECT * FROM 2014302580200_user" ;
			ResultSet rs = stmt.executeQuery(sql);
			while(rs.next()){
				account.add(rs.getString("account"));
				money.add(rs.getDouble("money"));
			}
			int index = account.indexOf(ACC);
			double mon = money.get(index) - 1;
			} catch (ClassNotFoundException | SQLException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
		
	}

}
