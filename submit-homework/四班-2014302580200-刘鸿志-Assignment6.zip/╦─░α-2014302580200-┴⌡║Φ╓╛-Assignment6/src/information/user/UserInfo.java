package information.user;

import java.sql.*;
import java.util.ArrayList;

public class UserInfo {
	public ArrayList<String> AccInfo;
	public ArrayList<String> PasInfo;
	public ArrayList<String> MailInfo;
	public ArrayList<Double> Money;
	
	public UserInfo(){
		AccInfo = new ArrayList<String>();
		PasInfo = new ArrayList<String>();
		MailInfo = new ArrayList<String>();
		Money = new ArrayList<Double>();
		getInfo();
	}
	
	public void getInfo(){
		final String URL = "jdbc:mysql://localhost:3306/my_schema?user=root&password=liu19960623&useUnicode=true&characterEncoding=UTF8";
		//final String URL = "jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456";
		final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
		Connection conn = null;
		Statement stmt = null;
		AccInfo = new ArrayList<String>();
		try {
			Class.forName(JDBC_DRIVER);
			conn = DriverManager.getConnection(URL);
			stmt = conn.createStatement();
			String sql = "SELECT account, password, mail, money FROM 2014302580200_user";
			ResultSet rs = stmt.executeQuery(sql);
			while(rs.next()){
				AccInfo.add(rs.getString("account"));
				PasInfo.add(rs.getString("password"));
				MailInfo.add(rs.getString("mail"));
				Money.add(rs.getDouble("money"));
				}
			rs.close();
			} catch (ClassNotFoundException | SQLException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}	
	}
}
