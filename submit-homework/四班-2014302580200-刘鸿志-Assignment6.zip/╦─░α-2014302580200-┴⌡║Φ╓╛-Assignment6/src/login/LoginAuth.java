package login;
import information.user.*;

import java.util.*;

public class LoginAuth {
	
	public LoginAuth(){
		
	}
	//��֤�ʺ��������
	public boolean Auth(String acc , String pas ){
		UserInfo usinfo = new UserInfo();
		if(!usinfo.AccInfo.contains(acc)){
			return false;
		}
		else{
			int index = usinfo.AccInfo.indexOf(acc);
			if (usinfo.PasInfo.get(index).equals(pas)){
				return false;
				}
			else{
				return true;
				}
			}
		}
}
