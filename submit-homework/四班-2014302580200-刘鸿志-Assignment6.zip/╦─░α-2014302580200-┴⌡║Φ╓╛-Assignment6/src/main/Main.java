package main;
import gui.*;
public class Main {
	public static void main(String args[]){
		LoginGui a = new LoginGui();
	}

}
