package register;


import java.util.Properties;

import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class SendMail {

	private String AddOfSender;
	private String AddOfReceiver;
	private transient Properties prop;
	private transient MailAuthenticator authenticator;
	private transient Session Sess;
	public SendMail(String receiver){
		AddOfReceiver = receiver;
		try {
			Send("123456");
		} catch (MessagingException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
	}
	public void Send(String code) throws MessagingException{
		Properties pro = System.getProperties();
		String username = "m13407134075@163.com";
		String password = "tyjccmfpbeccuegz";
		authenticator = new MailAuthenticator(username,password);
		pro.put("mail.smtp.host", "smtp.163.com");
		pro.put("mail.smtp.auth", "true");
		Session Ses = Session.getInstance(pro,authenticator);
		MimeMessage message = new MimeMessage(Ses);
		message.setSubject("���ﹺ��ƽ̨��֤��");
		message.setText(code);
		AddOfSender = "13407134075@163.com";
		Address FromAddr = new InternetAddress(AddOfSender);
		Address ToAddr = new InternetAddress(AddOfReceiver);
		message.setFrom(FromAddr);
		message.setRecipient(Message.RecipientType.TO, ToAddr);
		Transport.send(message);
		
	}
	
	private void setAddrOfSender(String s){
		AddOfSender = s;
	}
	public String getAddrOfSender(){
		return AddOfSender;
	}
	
	private void setAddrOfReceiver(String s){
		AddOfReceiver = s;
	}
	public String getAddrOfReceiver(){
		return AddOfReceiver;
	}
}
